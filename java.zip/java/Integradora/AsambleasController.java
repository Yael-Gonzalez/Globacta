package Integradora;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.event.ActionEvent;
import javafx.stage.Stage;

import java.sql.*;

public class AsambleasController {

    @FXML private FlowPane contenedorTarjetas;
    @FXML private Button btnRegresar;

    @FXML
    public void initialize() {
        cargarAsambleas();
    }

    private void cargarAsambleas() {
        try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@tu_host", "usuario", "contraseña");
             PreparedStatement stmt = conn.prepareStatement("SELECT nombre, lugar, fecha FROM asamblea");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String lugar = rs.getString("lugar");
                String fecha = rs.getString("fecha");

                Node tarjeta = crearTarjeta(nombre, lugar, fecha);
                contenedorTarjetas.getChildren().add(tarjeta);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Node crearTarjeta(String nombre, String lugar, String fecha) {
        VBox tarjeta = new VBox();
        tarjeta.setSpacing(5);
        tarjeta.setPrefSize(150, 100);
        tarjeta.setStyle(
                "-fx-background-color: white;" +
                        "-fx-padding: 10;" +
                        "-fx-border-radius: 10;" +
                        "-fx-background-radius: 10;" +
                        "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.1), 5, 0, 0, 1);"
        );

        Label lblNombre = new Label(nombre);
        lblNombre.setStyle("-fx-font-weight: bold; -fx-text-fill: #003366;");

        Label lblLugar = new Label("📍 " + lugar);
        Label lblFecha = new Label("📅 " + fecha);

        tarjeta.getChildren().addAll(lblNombre, lblLugar, lblFecha);

        // Evento para abrir el detalle
        tarjeta.setOnMouseClicked(e -> abrirDetalle(nombre, lugar, fecha));

        return tarjeta;
    }

    @FXML
    private void abrirFormulario(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/tu/paquete/CrearAsamblea.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void abrirDetalle(String nombre, String lugar, String fecha) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/tu/paquete/DetalleAsamblea.fxml"));
            Parent root = loader.load();

            DetalleAsambleaController controller = loader.getController();
            controller.setDatos(nombre, lugar, fecha);

            Stage stage = new Stage(); // o reemplaza escena si prefieres
            stage.setTitle("Detalle de Asamblea");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void regresar(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/tu/paquete/MenuPrincipal.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

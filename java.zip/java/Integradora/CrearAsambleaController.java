package Integradora;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

public class CrearAsambleaController {

    @FXML private TextField txtNombre;
    @FXML private TextField txtParticipantes;
    @FXML private TextField txtLugar;
    @FXML private TextField txtFecha;
    @FXML private TextField txtHoraInicio;
    @FXML private TextField txtHoraFin;
    @FXML private Button btnImportar;
    @FXML private Button btnCrear;

    // Acción para importar archivo
    @FXML
    private void importarArchivo(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar archivo de participantes");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos CSV", "*.csv"));
        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            System.out.println("Archivo seleccionado: " + file.getAbsolutePath());
            // Aquí puedes procesar el archivo si lo deseas
        }
    }

    // Acción para cambiar de página (por ejemplo, regresar al menú o ver lista de asambleas)
    @FXML
    private void crearAsamblea(ActionEvent event) {
        try {                                                               //aqui se pone el enlace de la pagina
            Parent root = FXMLLoader.load(getClass().getResource("/tu/paquete/vistas/ListaAsambleas.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


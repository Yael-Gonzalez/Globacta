package Integradora;
package tu.paquete;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.sql.*;

public class EditarParticipanteController {

    @FXML private TableView<Participante> tablaParticipantes;
    @FXML private TableColumn<Participante, Integer> colNumero;
    @FXML private TableColumn<Participante, String> colNombre;
    @FXML private TableColumn<Participante, String> colEscuela;
    @FXML private TableColumn<Participante, String> colRol;

    @FXML private TextField txtNumero, txtNombre, txtEscuela, txtRol;

    private ObservableList<Participante> lista = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colNumero.setCellValueFactory(data -> data.getValue().numeroProperty().asObject());
        colNombre.setCellValueFactory(data -> data.getValue().nombreProperty());
        colEscuela.setCellValueFactory(data -> data.getValue().escuelaProperty());
        colRol.setCellValueFactory(data -> data.getValue().rolProperty());

        cargarParticipantes();
    }

    private void cargarParticipantes() {
        try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@tu_host", "usuario", "contraseña");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM participantes")) {

            while (rs.next()) {
                Participante p = new Participante(
                        rs.getInt("numero"),
                        rs.getString("nombre"),
                        rs.getString("escuela"),
                        rs.getString("rol")
                );
                lista.add(p);
            }
            tablaParticipantes.setItems(lista);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void aceptar(ActionEvent event) {
        System.out.println("Aceptar presionado");
        // Aquí va tu lógica para guardar cambios
    }

    @FXML
    private void eliminar(ActionEvent event) {
        System.out.println("Eliminar presionado");
        // Aquí va tu lógica para eliminar registro
    }

    @FXML
    private void cancelar(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/tu/paquete/vistas/MenuPrincipal.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

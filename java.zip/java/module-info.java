module com.edu.utez.pruebaint {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.edu.utez.pruebaint to javafx.fxml;
    exports Integradora;
    opens Integradora to javafx.fxml;
}